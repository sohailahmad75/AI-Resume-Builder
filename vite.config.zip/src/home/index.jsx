import React from "react";
import Header from "@/components/custom/Header.jsx";

const Home = () => {
  return (
    <div>
      <Header />
      Home page
    </div>
  );
};

export default Home;
